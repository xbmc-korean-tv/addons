# -*- coding: utf-8 -*-
import urllib
import sys
import re
import navigator
import authenticator

try:
    import CommonFunctions
    common = CommonFunctions
except:
    import CommonFunctions2 as common

# http://www.tbogo.com

BrowserAgent = 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0)'
PlayerAgent  = 'Windows-Media-Player/12.0.7601.17514'

base_url = 'http://www.tbogo.com'
login_url = 'https://www.tbogo.com/member/?pg_mode=login_proc'
mypage_url = 'http://www.tbogo.com/mypage'
cookiefile = 'tbogo_cookie.lwp'

NORMAL_SCALE = 100
LARGE_SCALE = 1000

def high(options):
    index = [r for r, s in enumerate(options) if '720P' in s]

    if len(index) == 0:
        return med(options)
    
    return options[index[0]]

def med(options):
    index = [r for r, s in enumerate(options) if '450P' in s]

    if len(index) == 0:
        return low(options)
    
    return options[index[0]]

def low(options):
    index = [r for r, s in enumerate(options) if 'MP4' in s]

    if len(index) == 0:
        return options[0]
    
    return options[index[0]]

resolutions = { '0' : med, '1' : low, '2' : high}            
        
class Tvbogo:

    def __init__(self):
        self.nav = navigator.Navigator(base_url)
        self.auth = authenticator.Login(self.nav.opener, self.nav.cj)
        try:
            self.language = sys.modules["__main__"].settings.getLocalizedString
        except:
            pass        
        
    def login(self, username, password, cookiepath):
        data = urllib.urlencode({'userid':username, 'userpw':password}) 
        self.auth.login(login_url, mypage_url, data, cookiepath + cookiefile)
        
    def parseMenu(self):
        page = self.nav.getPage()
        result = []
        menu = common.parseDOM(page, 'div', {'class' : 'menu'})
        channels = common.parseDOM(menu, 'div', {"style":"float:left;"})

        # item list
        titles = common.parseDOM(channels[0], 'a')
        codes = common.parseDOM(channels[0], 'a', ret='href')

        items = zip (titles, codes)
        for img, url in items:
            try:
                title = common.parseDOM(img, 'img', ret='alt')[0]
                sindex = url.find('code')
                result.append({'title':title, 'url':url, 'thumb':'', 'mode':'browse'})                
            except:
                continue
                
        return result

    def parseNewMedia(self, url, mtype='onair'):
        result = []
        try:
            params = common.getParameters(url)
        except:
            params = {}

        code = params.get('code', '')

        try:
            result.append({'title':'[ ' + self.language(32000) + ' ]', 'url':'?pg_mode=xml&code=' + code, 'thumb':'', 'mode':'browseOnAir'})    
            result.append({'title':'[ ' + self.language(32001) + ' ]', 'url':'?pg_mode=xml&code=' + code, 'thumb':'', 'mode':'browseOffAir'})
        except:
            pass

        self.getList(code, 0, mtype, result, NORMAL_SCALE, True, 'play')
        
        return result
    
    def parseMedia(self, url, mtype='onair'):
        result = []
        try:
            params = common.getParameters(url)
        except:
            params = {}

        code = params.get('code', '')
        idx = params.get('idx', '')
        start = params.get('start', '0')
        total = params.get('total', '0')
        
        if idx == '':
            return self.getLists(code, mtype)
        else:
            return self.getBLists(idx, int(start), int(total))

    def getVideo(self, bidx, res):
        try:
            print 'Get Video = ' + bidx + ' ' + res
            
            vlink = '/media/?pg_mode=stream_proc&streammode=A&bidx=' + bidx + '&res=' + res
            page = self.nav.getPage(vlink).replace("'", "")
            vinfo = page[page.find("(")+1:].split(',')
            vtitle = vinfo[2]
            vurl = vinfo[0]

            return {'title':vtitle, 'url':vurl}
        except:
            print 'Unable to get video link for ' + evurl
            print page            
            return {'url':''}
        
    def parseVideo(self, url, quality):
        try:
            params = common.getParameters(url)
        except:
            params = {}

        idx = params.get('idx', '')
        bidx = params.get('bidx', '')        

        if bidx == '':
            bidx = self.getBidx(idx)

        print 'Bidx = ' + bidx
        
        try:
            page = self.nav.getPage('/media/?pg_mode=download&bidx=' + bidx)
            roptions = common.parseDOM(page, 'img', ret='onclick')
            
            print 'Quality = ' + quality
            res = resolutions[quality](roptions)            
            res = res[res.find("'")+1:res.rfind("'")].encode('utf-8')
            
            cookies = []
            for cookie in self.nav.cj:
                cookies.append( cookie.name+'='+cookie.value )
            ckStr = ';'.join(cookies)

            vurl = self.getVideo(bidx, res)

            for quality in sorted(resolutions.iterkeys()):
                if vurl['url'] == '':                
                    res = resolutions[quality](roptions)            
                    vurl = self.getVideo(bidx, res)
                else:                    
                    return {'title':vurl['title'], 'url':vurl['url'], 'useragent':PlayerAgent, 'cookie':ckStr}            
        except:
            return {}

    def getBidx(self, idx):
        print 'getBidx = ' + idx
        page = self.nav.getPage('/media/?pg_mode=xml_blist&idx=' + idx)
        postDate = ''
        result = []

        items = common.parseDOM(page, 'list')
        for item in items:                         
            try:                
                if postDate == '':
                    postDate = common.parseDOM(item, 'span', {'class':'postDate'})[0]

                if postDate != common.parseDOM(item, 'span', {'class':'postDate'})[0]:
                    break
                                               
                bbtn = common.parseDOM(item, 'bbtn')[0]
                actions = common.parseDOM(bbtn, 'li', ret='onclick')
                action = [x for x in actions if 'stream' in x]

                if len(action) != 0:
                    action = action[0].split('stream_download(')
                    print action

                    if len(action) == 2:
                        action = action[1]                        
                    else:
                        action = action[0]
                        
                    info = action[action.rfind(',')+1:]
                    bidx = info.replace(')', '')
                    result.append(bidx)
                    print 'stream Bidx = ' + bidx                
                else:
                    action = [x for x in actions if 'download' in x]

                    if len(action) != 0:
                        action = action[0].split('download(')
                        print action

                        if len(action) == 2:
                            action = action[1]                        
                        else:
                            action = action[0]
                            
                        info = action[action.rfind(',')+1:]
                        bidx = info.replace(')', '')
                        result.append(bidx)
                        print 'download Bidx = ' + bidx                
            except:
                print 'Exception in' + item
                                               
        return bidx
                                
    def getLists(self, code, mtype):
        result = []

        total = self.getList(code, 0, mtype, result)
        
        while len(result) < total:
            rsize = len(result)
            self.getList(code, rsize, mtype, result)
            if rsize == len(result):            
                break
            
        return result

    def getList(self, code, start, mtype, result, scale=LARGE_SCALE, playable=False, mode='browseAll'):
        page = self.nav.getPage('/media/?pg_mode=xml&code=' + code + '&scale=' + str(scale) + '&start=' + str(start) + '&type=' + mtype)
        
        #item list
        total = int(common.parseDOM(page, 'total')[0])

        items = common.parseDOM(page, 'list')
        for item in items:
            try:
                info = common.parseDOM(item, 'title')
                title = common.parseDOM(info, 'a', ret = 'title')[0]
                sindex = title.find('<')
                if sindex != -1:
                    title = title[:sindex]
                url = common.parseDOM(info, 'a', ret='href')[0]
                img = common.parseDOM(item, 'img')                   
                thumb = common.parseDOM(img, 'img', ret='src')[0]
                
                result.append({'title':title, 'url': url, 'thumb':thumb, 'playable':playable, 'mode':mode})
            except:
                continue
            
        return total

    def getBLists(self, idx, start=0, total=0):
        result = []

        if start == 0:
            info = self.getBList(idx, 0, result)
            result.append({'title':'[ ' + self.language(33001) + ' ]', 'url':'?pg_mode=xml&idx=' + idx + '&start=' + str(info['start']) + '&total=' + str(info['total']), 'thumb':'', 'mode':'browseOffAir'})
        else:            
            for i in range(start, total, start):
                self.getBList(idx, i,  result)            

        return result
                
    def getBList(self, idx, start, result):
        page = self.nav.getPage('/media/?pg_mode=xml_blist&idx=' + idx + '&start=' + str(start))

        #item list
        total = int(common.parseDOM(page, 'total')[0])
    
        items = common.parseDOM(page, 'list')        
        for item in items:
            try:
                img = common.parseDOM(item, 'bthumb')
                thumb = common.parseDOM(img, 'img', ret='src')[0]        
                bbtn = common.parseDOM(item, 'bbtn')[0]
                actions = common.parseDOM(bbtn, 'li', ret='onclick')
                action = [x for x in actions if 'stream' in x]
                
                if len(action) != 0:
                    action = action[0].split('stream_download(')

                    if len(action) == 2:
                        action = action[1]
                    else:
                        action = action[0]
                    
                    info = action[action.rfind(',')+1:]
                    title = action[:action.rfind(',')]
                    title = title[:title.find('&gt;') + 4]
                    title = title.replace("'", '')
                    url = '/media/?idx=' + idx + '&bidx=' + info.replace(')', '')
                    result.append({'title':title, 'url':url, 'thumb':thumb, 'playable':True, 'mode':'play'})
                else:
                    action = [x for x in actions if 'download' in x]

                    if len(action) != 0 and (len(result) == 0 or result[0].get('type', '') == 'audio'):
                        action = action[0].split('download(')

                        if len(action) == 2:
                            action = action[1]
                        else:
                            action = action[0]
                        
                        info = action[action.rfind(',')+1:]
                        title = action[:action.rfind(',')]
                        title = title[:title.find('&gt;') + 4]
                        title = title.replace("'", '')
                        bidx = info.replace(')', '')
                        url = '/media/?idx=' + idx + '&bidx=' + bidx
                        page = self.nav.getPage('/media/?pg_mode=download&bidx=' + bidx)
                        table = common.parseDOM(page, 'table')
                        div = common.parseDOM(table, 'div')                        
                        roptions = common.parseDOM(page, 'input', {'type':'radio'}, 'value')
                        roptions = [r for r in roptions if r != 'XVID']
                        if len(roptions) != 0:                            
                            result.append({'title':title, 'url':url, 'thumb':thumb, 'playable':True, 'mode':'play'})
                        elif any('MP3' in res for res in div):
                            result.append({'title':title, 'url':url, 'thumb':thumb, 'playable':True, 'mode':'play', 'type':'audio'})
            except:                
                continue

        return {'total': total, 'start':len(items)}
    
# vim:sw=4:sts=4:et
