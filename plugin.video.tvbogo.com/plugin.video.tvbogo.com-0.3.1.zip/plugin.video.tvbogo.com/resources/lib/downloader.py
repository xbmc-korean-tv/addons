# -*- coding: utf-8 -*-
import urllib2
import cookielib

try:
    import xbmcvfs    
except:
    xbmcvfs = ''

class Downloader:

        def __init__(self, opener, path):
                print 'Init: Downloader (' + path + ')'
                self.path = path
                self.opener = opener
                
        def download(self, url, folder, filename):
                ext = '.mp4'
                vfile = self.path.encode('utf-8')
                vfile += '/'
                vfile += folder.strip()
                vfile += '/'
                vfile += filename.strip()
                vfile += ext
                print 'Download ' + vfile.encode('utf-8')

                r = self.opener.open(url)
                f = xbmcvfs.File(vfile, 'wb')            
                
                chunk_size = 1024 * 8
                while True:
                        chunk = r.read(chunk_size)
                        if not chunk:
                                break;                        
                        f.write(chunk)
                        
                r.close()
                f.close()
                
                return True
                   
        
# vim:sw=4:sts=4:et
