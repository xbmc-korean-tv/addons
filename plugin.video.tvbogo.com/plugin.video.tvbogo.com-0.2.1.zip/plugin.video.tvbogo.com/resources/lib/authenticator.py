# -*- coding: utf-8 -*-
import os

try:
    import CommonFunctions
    common = CommonFunctions
except:
    import CommonFunctions2 as common
    
class Login:

        def __init__(self, opener, cj):
                self.cj = cj
                self.opener = opener
  
        def login(self, login_url, mypage_url, data, cookiefile='cookie.lwp'):                
                if (os.path.isfile(cookiefile)):
                        self.cj.load(cookiefile, True)

                page = self.opener.open(mypage_url).read()
                if page.find('/member/?pg_mode=login&go_url') != -1:
                        params = common.getParameters(page)                        
                        print 'Login to ' + login_url
                        print params
                        self.opener.open(login_url, data)
                        self.cj.save(cookiefile, True)                

# vim:sw=4:sts=4:et
