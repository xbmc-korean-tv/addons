# -*- coding: utf-8 -*-
import urllib
import sys
import re
import navigator
import authenticator
import json

try:
    import CommonFunctions
    common = CommonFunctions
except:
    import CommonFunctions2 as common

# http://www.tbogo.com

BrowserAgent = 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0)'
PlayerAgent  = 'Windows-Media-Player/12.0.7601.17514'

base_url = 'http://www.tbogo.com'
login_url = 'https://www.tbogo.com/member/index_ajax.php'
mypage_url = 'http://www.tbogo.com/mypage'
cookiefile = 'tbogo_cookie.lwp'

NORMAL_SCALE = 100
LARGE_SCALE = 1000

def high(options):
    index = [r for r, s in enumerate(options) if '720P' in s]

    if len(index) == 0:
        return med(options)
    
    return options[index[0]]

def med(options):
    index = [r for r, s in enumerate(options) if '450P' in s]

    if len(index) == 0:
        return low(options)
    
    return options[index[0]]

def low(options):
    index = [r for r, s in enumerate(options) if 'MP4' in s]

    if len(index) == 0:
        return options[0]
    
    return options[index[0]]

resolutions = { '0' : med, '1' : low, '2' : high}            
        
class Tvbogo:

    def __init__(self):
        self.nav = navigator.Navigator(base_url)
        self.auth = authenticator.Login(self.nav.opener, self.nav.cj)
        try:
            self.language = sys.modules["__main__"].settings.getLocalizedString
        except:
            pass        
        
    def login(self, username, password, cookiepath):
        data = urllib.urlencode({'pname':username, 'userpw':password, 'log_info':1, 'pg_mode':'login_proc'}) 
        self.auth.login(login_url, mypage_url, data, cookiepath + cookiefile)
        
    def parseMenu(self):
        result = []
        result.append({'title':'드라마', 'url':'/media/?code=B01', 'thumb':'', 'mode':'browse'})
        result.append({'title':'예능/오락', 'url':'/media/?code=B02', 'thumb':'', 'mode':'browse'})
        result.append({'title':'시사다큐', 'url':'/media/?code=B03', 'thumb':'', 'mode':'browse'})
        result.append({'title':'뉴스', 'url':'/media/?code=B03news', 'thumb':'', 'mode':'browse'})
        result.append({'title':'키즈', 'url':'/media/?code=B05', 'thumb':'', 'mode':'browse'})
        result.append({'title':'영화', 'url':'/media/?code=M01', 'thumb':'', 'mode':'browse'})
        return result

    def parseNewMedia(self, url, mtype='recently'):
        result = []
        try:
            params = common.getParameters(url)
        except:
            params = {}

        code = params.get('code', '')

        try:
            result.append({'title':'[ ' + self.language(32000) + ' ]', 'url':'/onair?code=' + code, 'thumb':'', 'mode':'browseOnAir', 'opening':'POPULAR'})    
            result.append({'title':'[ ' + self.language(32001) + ' ]', 'url':'/offair?code=' + code, 'thumb':'', 'mode':'browseOffAir', 'opening':'OFFAIR'})
        except:
            pass

        self.getList(code, 0, mtype, result, NORMAL_SCALE, True, 'play')
        
        return result
    
    def parseMedia(self, url, mtype='popular'):
        result = []
        try:
            params = common.getParameters(url)
        except:
            params = {}

        code = params.get('code', '')
        idx = params.get('idx', '')
        start = params.get('start', '0')
        total = params.get('total', '0')
        
        if idx == '':
            return self.getLists(code, mtype)
        else:
            return self.getBLists(idx, int(start), int(total))

    def getVideo(self, bidx, oidx):
        try:
            print 'Get Video = ' + bidx + ' ' + oidx
            
            vlink = '/media/?pg_mode=view&smode=watch&pno=B' + bidx + '&objid='+ oidx
            video = self.nav.getPage(vlink)
            sidx = video.find("file :")
            vurl = video[video.find("http:", sidx):video.find("mp4",sidx)+3]            
            if vurl == '':
                vurl = video[video.find("https:", sidx):video.find("',",sidx)]            				
            if vurl == '':
                print 'Error: Unable to resolve video url'
                print vlink
                print video
            return {'title':vurl, 'url':vurl}
        except:
            print 'Unable to get video link for ' + evurl
            print page            
            return {'url':''}
        
    def parseVideo(self, url, quality):
        try:
            params = common.getParameters(url)
        except:
            params = {}

        idx = params.get('idx', '')
        bidx = params.get('bidx', '')
        
        if bidx == '':
            bidx = self.getBidx(idx)

        print 'Bidx = ' + bidx
        
        page = self.nav.getPage('/media/index_ajax.php', 'pg_mode=user_charge&smode=stream&resolution=450P&price=0&pnum=B' + bidx)
        print '/media/index_ajax.php?pg_mode=user_charge&smode=stream&resolution=450P&price=0&pnum=B' + bidx
        items = json.loads(page)
        oidx = str(items['objid'])
            
        print 'ObjID = ' + oidx
            
        vurl = self.getVideo(bidx, oidx)
            				
        cookies = []
        for cookie in self.nav.cj:
            cookies.append( cookie.name+'='+cookie.value )
        ckStr = ';'.join(cookies)
			
        return {'title':vurl['title'], 'url':vurl['url'], 'useragent':PlayerAgent, 'cookie':ckStr}        

    def getBidx(self, idx):
        print 'getBidx = ' + idx
        page = self.nav.getPage('/media/index_ajax.php', 'pg_mode=episode&lang=KR&list_scale=1000&pnum=' + idx)
        result = []

        items = json.loads(page)
        bidx = items['0']['bidx']
        return bidx
                                
    def getLists(self, code, mtype):
        result = []

        total = self.getList(code, 0, mtype, result)            
        return result

    def getList(self, code, start, mtype, result, scale=LARGE_SCALE, playable=False, mode='browseAll'):
        area = ''
        
        if code == 'M':
            code = 'M01'

        nidx = code.find('news')
        if nidx != -1:
            code = code[:nidx]
            area = 'news'        
            
        print 'URL: ' + '/media/index_ajax.php?pg_mode=' + mtype + '&lang=KR&code=' + code + '&list_scale=' + str(scale) + '&list_page=' + str(start)
        page = self.nav.getPage('/media/index_ajax.php', 'pg_mode=' + mtype + '&lang=KR&code=' + code + '&list_scale=' + str(scale) + '&list_page=' + str(start))
        
        items = json.loads(page)        

        #item list
        total = items['0'].get('total_cnt', 0)

        for idx in items:
            try:
                title = ''
                opening = items[idx].get('opening', '')
                if opening == 'Dec 31, 1969':
                    opening = ''
                if opening != '':
                    title = opening + ': '
                title = title + items[idx]['title']
                thumb = items[idx]['imgUrl']
                url = '?idx=M' + items[idx]['midx'] + '&bidx=' + items[idx].get('bidx', '')                
                
                result.append({'title':title, 'url': url, 'thumb':thumb, 'playable':playable, 'mode':mode, 'opening':opening})
            except:
                continue
            
        return total

    def getBLists(self, idx, start=0, total=0):
        result = []
        info = self.getBList(idx, 0, result)        
        return result
                
    def getBList(self, idx, start, result):
        page = self.nav.getPage('/media/index_ajax.php', 'pg_mode=episode&pnum=' + idx + '&lang=KR&list_scale=1000')
        print 'URL: ' + '/media/index_ajax.php?pg_mode=episode&pnum=' + idx + '&lang=KR&list_scale=1000'

        items = json.loads(page)
        
        #item list
        total = items['0'].get('total_cnt', 0)

        for item in items:
            try:
                title = ''
                opening = items[item].get('opening', '')
                if opening == 'Dec 31, 1969':
                    opening = ''
                if opening != '':
                    title = opening + ': '
                title = title + items[item]['title']
                midx = items[item].get('midx', '')
                bidx = items[item].get('bidx', '')                
                thumb = items[item].get('imgUrl', '')
                url = '?idx=' + idx + '&bidx=' + bidx
                
                result.append({'title':title, 'url':url, 'thumb':thumb, 'playable':True, 'mode':'play', 'opening':opening})                
            except:                
                continue

        return {'total': total, 'start':len(items)}
    
# vim:sw=4:sts=4:et
