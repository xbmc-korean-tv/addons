# -*- coding: utf-8 -*-
import urllib2
import cookielib

class Navigator:

        def __init__(self, base_url):
                print 'Init: Navigator (' + base_url + ')'
                self.base_url = base_url
                self.cj = cookielib.LWPCookieJar()
                self.opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(self.cj))
                
        def getPage(self, url='', data=''):
                request = urllib2.Request(self.base_url + url, data=data)
                page = self.opener.open(request).read()
                return page        
        
# vim:sw=4:sts=4:et
