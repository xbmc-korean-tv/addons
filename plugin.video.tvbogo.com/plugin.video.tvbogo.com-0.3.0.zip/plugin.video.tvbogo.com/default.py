from xbmcswift2 import Plugin, xbmc, xbmcgui, xbmcaddon, actions
from resources.lib import tvbogo
from resources.lib import navigator
from resources.lib import downloader
import cookielib
import re
import xbmcvfs
import datetime
import time

plugin = "Tvbogo Video"
__url__ = 'https://code.google.com/p/korean-drama-tv/'
__date__ = '08-18-2018'
__version__ = '0.3.0'
settings = xbmcaddon.Addon(id='plugin.video.tvbogo.com')
cookiepath = xbmc.translatePath('special://temp/')

plugin = Plugin()
parser = tvbogo.Tvbogo()
downloader = downloader.Downloader(parser.nav.opener, plugin.get_setting('download_dir', unicode))

datefmt1 = "%b %d, %Y"
datefmt2 = "%Y.%m.%d"

def strip_html(text):
  def fixup(m):
    text = m.group(0)
    if text[:1] == "<":
      return "" # ignore tags
    if text[:2] == "&#":
      try:
        if text[:3] == "&#x":
          return unichr(int(text[3:-1], 16))
        else:
          return unichr(int(text[2:-1]))
      except ValueError:
        pass
    elif text[:1] == "&":
      import htmlentitydefs
      entity = htmlentitydefs.entitydefs.get(text[1:-1])
      if entity:
        if entity[:2] == "&#":
          try:
            return unichr(int(entity[2:-1]))
          except ValueError:
            pass
        else:
          return unicode(entity, "iso-8859-1")
    return text # leave as is
  return re.sub("(?s)<[^>]*>|&#?\w+;", fixup, text)
  
def checkLoginInfo():
  if settings.getSetting('username') == '' or settings.getSetting('password') == '':
    settings.openSettings()
    return True
  return True
                                           
def addItems(items):
  result = []
  order = True
  skip = False

  label_download= plugin.get_string(30100)
  for item in items:
    try:
      title = item['title']
      playable = item.get('playable', False)

      if item.get('opening', '') == '':
        order = False

      if item.get('opening', '') == 'OFFAIR':
        skip = True

      if playable:
        result.append({
          'label':strip_html(item['title']),
          'path':plugin.url_for(item['mode'], url=item['url']),
          'is_playable':True,
	  'context_menu':[(label_download, actions.background(plugin.url_for('download', url=item['url'])))],
          'thumbnail':''})
          #'thumbnail':item['thumb']})
      else:
        result.append({
          'label':strip_html(item['title']),
          'path':plugin.url_for(item['mode'], url=item['url'])})

    except:      
      print 'Unable to add the media'
      print item
      
  if skip == True:
    if order == True:
      try:
        retValue = sorted(result[2:], cmp=lambda a,b: cmp(time.strptime(a, datefmt2), time.strptime(b, datefmt2)), key=lambda k:k['label'][:k['label'].find(':')], reverse=True)
      except:
        retValue = sorted(result[2:], cmp=lambda a,b: cmp(time.strptime(a, datefmt1), time.strptime(b, datefmt1)), key=lambda k:k['label'][:k['label'].find(':')], reverse=True)
    else:
      retValue = sorted(result[2:], key=lambda k:k['label'], reverse=False)
    retValue.insert(0, result[0])
    retValue.insert(0, result[1])
  else:
    if order == True:
      try:
        retValue = sorted(result, cmp=lambda a,b: cmp(time.strptime(a, datefmt2), time.strptime(b, datefmt2)), key=lambda k:k['label'][:k['label'].find(':')], reverse=True)
      except:
        retValue = sorted(result, cmp=lambda a,b: cmp(time.strptime(a, datefmt1), time.strptime(b, datefmt1)), key=lambda k:k['label'][:k['label'].find(':')], reverse=True)
    else:
      retValue = sorted(result, key=lambda k:k['label'], reverse=False)

  return retValue;

@plugin.route('/')
def index():
  menu = parser.parseMenu()
  return addItems(menu)

@plugin.cached_route('/onair/<url>')
def browseOnAir(url):
  menu = parser.parseMedia(url, 'popular')
  result = []  
  return addItems(menu)

@plugin.cached_route('/offair/<url>')
def browseOffAir(url):
  menu = parser.parseMedia(url, 'offair')
  result = []  
  return addItems(menu)

@plugin.route('/all_media/<url>')
def browseAll(url):
  menu = parser.parseMedia(url)
  result = []  
  return addItems(menu)

@plugin.route('/media/<url>')
def browse(url):
  menu = parser.parseNewMedia(url)
  result = []  
  return addItems(menu)

@plugin.route('/video/<url>')
def play(url):
  info = parser.parseVideo(url, settings.getSetting('quality'))  
  vurl = "{0:s}|User-Agent={1:s}&Cookie={2:s}".format(info['url'], info['useragent'], info['cookie'])  
  plugin.set_resolved_url(vurl)

@plugin.route('/file/<url>')
def download(url):
  wdir = plugin.get_setting('download_dir', unicode)

  if not xbmcvfs.exists(wdir):
    return plugin.finish(None, succeeded=False)
    
  print 'Download ' + url
  info = parser.parseVideo(url, settings.getSetting('quality'))

  title = info['title']
  folder = re.sub("(?s)<[^>]*>|&#?\w+;", '', title).strip()
  filename = re.sub('[\/:*"<>]', '', title).strip()

  if not xbmcvfs.exists(wdir+folder):
    xbmcvfs.mkdir(wdir+folder)

  plugin.notify(title.encode('utf-8') + ' ' + plugin.get_string(30100).encode('utf-8'))
  if downloader.download(info['url'], folder, filename):
    plugin.notify(title.encode('utf-8') + ' ' + plugin.get_string(30101).encode('utf-8'))
    return plugin.finish(None, succeeded=True)
  else:
    return plugin.finish(None, succeeded=False)

if __name__ == '__main__':
  if checkLoginInfo():
    parser.login(settings.getSetting('username'), settings.getSetting('password'), cookiepath)
    plugin.run()
