from xbmcswift2 import Plugin, xbmc, xbmcgui, xbmcaddon
import os.path
import xbmcvfs

# plugin constants
__addonid__ = "plugin.video.ktv-onair"
__url__ = 'https://github.com/KTVOnAir/addons/plugin.video.ktv-onair'
__addon__   = xbmcaddon.Addon(__addonid__)
__date__ = '03-10-2015'
__version__ = '0.0.6'
_L = __addon__.getLocalizedString
userpath = xbmc.translatePath('special://userdata/')
advancedsetting = os.path.join(userpath, 'advancedsettings.xml')
homepath = xbmc.translatePath('special://home')
defaultsetting = os.path.join(homepath, 'addons', 'plugin.video.ktv-onair', 'default.settings')

plugin = Plugin()

news = [
  {'title':_L(30018),
   'url':'plugin://plugin.video.tvbogo.com/video/%2Fmedia%2F%3Fpg_mode%3Dview%26idx%3D167',
   'thumb':'http://image.sbs.co.kr/sbs/news_migration/new_program/01.8news_weekday/01_news_img_574.jpg'},   
  {'title':_L(30019),
   'url':'plugin://plugin.video.tvbogo.com/video/%2Fmedia%2F%3Fpg_mode%3Dview%26idx%3D170',
   'thumb':'http://img.imnews.imbc.com/images/title/nwdesk.gif'},
  {'title':_L(30020),
   'url':'plugin://plugin.video.tvbogo.com/video/%2Fmedia%2F%3Fpg_mode%3Dview%26idx%3D169',
   'thumb':'http://news.kbs.co.kr/images/2013/sub/program_tit/MIDLE/0001_M.gif'},
  {'title':_L(30000),
   'url':'plugin://plugin.video.live-korean-tv/video/kbs/rtmp%3A%2F%2Flive.kbskme.gscdn.com%2F1tv%2F_definst_%2F1tv_5.stream/11/TV',
   'thumb':'http://img.kbs.co.kr/kplayer/WebV3/assets/images/channel_logo/large/channel_11.png'},  
    {'title':_L(30002),
   'url':'plugin://plugin.video.live-korean-tv/video/kbs/rtmp%3A%2F%2Flive.kbskme.gscdn.com%2Fnews24%2F_definst_%2Fnews24_800.stream/81/TV',
   'thumb':'http://img.kbs.co.kr/kplayer/WebV3/assets/images/channel_logo/large/channel_81.png'},
  {'title':_L(30016),
   'url':'plugin://plugin.video.live-korean-tv/video/eot/%2Furl2%3Fchannel%3D20%26player%3Dweb%26network%3Dpc/TV/0500',
   'thumb':'http://ytn.co.kr/img/_top/new_ytnlogo.gif'}
  ]

channels = [
  {'title':_L(30001),
   'url':'plugin://plugin.video.live-korean-tv/video/kbs/rtmp%3A%2F%2Flive.kbskme.gscdn.com%2F2tv%2F_definst_%2F2tv_5.stream/12/TV',
   'thumb':'http://img.kbs.co.kr/kplayer/WebV3/assets/images/channel_logo/large/channel_12.png'},
  {'title':_L(30003),
   'url':'plugin://plugin.video.live-korean-tv/video/kbs/rtmp%3A%2F%2Flive.kbskme.gscdn.com%2Fkbsn_drama%2F_definst_%2Fkbsn_drama_5.stream/N91/TV',
   'thumb':'http://img.kbs.co.kr/kplayer/WebV3/assets/images/channel_logo/large/channel_N91.png'},
  {'title':_L(30004),
   'url':'plugin://plugin.video.live-korean-tv/video/kbs/rtmp%3A%2F%2Flive.kbskme.gscdn.com%2Fkbsn_prime%2F_definst_%2Fkbsn_prime_5.stream/N93/TV',
   'thumb':'http://img.kbs.co.kr/kplayer/WebV3/assets/images/channel_logo/large/channel_N93.png'},
  {'title':_L(30005),
   'url':'plugin://plugin.video.live-korean-tv/video/kbs/rtmp%3A%2F%2Flive.kbskme.gscdn.com%2Fkbsn_joy%2F_definst_%2Fkbsn_joy_5.stream/N92/TV',
   'thumb':'http://img.kbs.co.kr/kplayer/WebV3/assets/images/channel_logo/large/channel_N92.png'},
  {'title':_L(30006),
   'url':'plugin://plugin.video.live-korean-tv/video/kbs/rtmp%3A%2F%2Flive.kbskme.gscdn.com%2Fkbs_worldtv%2F_definst_%2Fkbs_worldtv_4.stream/14/TV',
   'thumb':'http://img.kbs.co.kr/kplayer/WebV3/assets/images/channel_logo/large/channel_14.png'},
  {'title':_L(30007),
   'url':'plugin://plugin.video.live-korean-tv/video/mbc/%2Fplayer%2Fonair.aspx/TV/TV',
   'thumb':'http://image.tving.com/upload/cms/caic/CAIC0400/C00711.png'},
  {'title':_L(30008),
   'url':'plugin://plugin.video.live-korean-tv/video/mbc/%2Fplayer%2Fonairplus.aspx/TV/TV',
   'thumb':'http://guide.imbc.com/images/h2-onairplus.png'},
  {'title':_L(30017),
   'url':'plugin://plugin.video.live-korean-tv/video/eot/%2Furl2%3Fchannel%3D343%26player%3Dweb%26network%3Dpc/TV/0100',
   'thumb':'http://images.jtbc.joins.com/ui_jtbc/index/v3/t_jtbc_index.gif'},
    {'title':_L(30002),
   'url':'plugin://plugin.video.live-korean-tv/video/kbs/rtmp%3A%2F%2Flive.kbskme.gscdn.com%2Fnews24%2F_definst_%2Fnews24_800.stream/81/TV',
   'thumb':'http://img.kbs.co.kr/kplayer/WebV3/assets/images/channel_logo/large/channel_81.png'},
  {'title':_L(30016),
   'url':'plugin://plugin.video.live-korean-tv/video/eot/%2Furl2%3Fchannel%3D20%26player%3Dweb%26network%3Dpc/TV/0500',
   'thumb':'http://ytn.co.kr/img/_top/new_ytnlogo.gif'},
  {'title':_L(30024),
   'url':'plugin://plugin.video.live-korean-tv/video/eot/%2Furl2%3Fchannel%3D251%26player%3Dweb%26network%3Dpc/TV/0100',
   'thumb':'http://img.ichannela.com/images/common/logo_2014.png'},
  {'title':_L(30025),
   'url':'plugin://plugin.video.live-korean-tv/video/eot/%2Furl2%3Fchannel%3D17%26player%3Dweb%26network%3Dpc/TV/0100',
   'thumb':'http://img.mbn.co.kr/newmbn/main2014/mbn_logo.gif'},
  {'title':_L(30026),
   'url':'plugin://plugin.video.live-korean-tv/video/eot/%2Furl2%3Fchannel%3D341%26player%3Dweb%26network%3Dpc/TV/0100',
   'thumb':'http://image.chosun.com/cstv_new/upload_img/bi/thumb_1360299206495.gif'},
  {'title':_L(30027),
   'url':'plugin://plugin.video.live-korean-tv/video/eot/%2Furl2%3Fchannel%3D43%26player%3Dweb%26network%3Dpc/TV/1000',
   'thumb':'http://www.beyonddonga.com/images/main/logo.png'},
  {'title':_L(30028),
   'url':'plugin://plugin.video.live-korean-tv/video/eot/%2Furl2%3Fchannel%3D133%26player%3Dweb%26network%3Dpc/TV/0500',
   'thumb':'http://img.yonhapnews.co.kr/basic/svc/00_ko/home/yonhap_fb_logo.png'},
  {'title':_L(30029),
   'url':'plugin://plugin.video.live-korean-tv/video/eot/%2Furl2%3Fchannel%3D423%26player%3Dweb%26network%3Dpc/TV/0400'},
  {'title':_L(30030),
   'url':'plugin://plugin.video.live-korean-tv/video/eot/%2Furl2%3Fchannel%3D58%26player%3Dweb%26network%3Dpc/TV/0400'},
  {'title':_L(30031),
   'url':'plugin://plugin.video.live-korean-tv/video/eot/%2Furl2%3Fchannel%3D929%26player%3Dweb%26network%3Dpc/TV/0400'},
  {'title':_L(30032),
   'url':'plugin://plugin.video.live-korean-tv/video/eot/%2Furl2%3Fchannel%3D902%26player%3Dweb%26network%3Dpc/TV/0400'},
  ]

vods = [
  {'title':_L(30021),
   'url':'plugin://plugin.video.tvbogo.com/onair/%3Fpg_mode%3Dxml%26code%3DB01',
   'playable':False},   
  {'title':_L(30022),
   'url':'plugin://plugin.video.tvbogo.com/onair/%3Fpg_mode%3Dxml%26code%3DB02',
   'playable':False},
  {'title':_L(30023),
   'url':'plugin://plugin.video.tvbogo.com/onair/%3Fpg_mode%3Dxml%26code%3DB03',
   'playable':False}
  ]

@plugin.route('/onair/')
def browseOnAir():
  result = []
  for channel in channels:      
    result.append({
      'label':channel['title'],
      'path':channel['url'], 
      'is_playable':channel.get('playable', True),
      'thumbnail':channel.get('thumb', '')})
  return result;

@plugin.route('/news/')
def browseNews():
  result = []
  for channel in news:      
    result.append({
      'label':channel['title'],
      'path':channel['url'], 
      'is_playable':channel.get('playable', True),
      'thumbnail':channel.get('thumb', '')})            
  return result;

@plugin.route('/vods/')
def browseVod():
  result = []
  for channel in vods:      
    result.append({
      'label':channel['title'],
      'path':channel['url'], 
      'is_playable':channel.get('playable', True),
      'thumbnail':channel.get('thumb', '')})            
  return result;


if __name__ == '__main__':
  if not xbmcvfs.exists(advancedsetting):
       if xbmcvfs.exists(defaultsetting):
         xbmcvfs.copy(defaultsetting, advancedsetting)
  plugin.run()
