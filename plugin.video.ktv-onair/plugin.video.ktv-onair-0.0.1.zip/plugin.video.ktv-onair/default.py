from xbmcswift2 import Plugin, xbmc, xbmcgui, xbmcaddon

# plugin constants
__addonid__ = "plugin.video.ktv-onair"
__url__ = 'https://github.com/KTVOnAir/addons/plugin.video.ktv-onair'
__addon__   = xbmcaddon.Addon(__addonid__)
__date__ = '05-26-2014'
__version__ = '0.0.1'
_L = __addon__.getLocalizedString

plugin = Plugin()

news = [
  {'title':_L(30018),
   'url':'plugin://plugin.video.tvbogo.com/video/%2Fmedia%2F%3Fpg_mode%3Dview%26idx%3D167',
   'thumb':'http://image.sbs.co.kr/sbs/news_migration/new_program/01.8news_weekday/01_news_img_574.jpg'},   
  {'title':_L(30019),
   'url':'plugin://plugin.video.tvbogo.com/video/%2Fmedia%2F%3Fpg_mode%3Dview%26idx%3D170',
   'thumb':'http://img.imnews.imbc.com/images/title/nwdesk.gif'},
  {'title':_L(30020),
   'url':'plugin://plugin.video.tvbogo.com/video/%2Fmedia%2F%3Fpg_mode%3Dview%26idx%3D169',
   'thumb':'http://news.kbs.co.kr/images/2013/sub/program_tit/MIDLE/0001_M.gif'},
  {'title':_L(30000),
   'url':'plugin://plugin.video.live-korean-tv/video/kbs/rtmp%3A%2F%2Flive.kbskme.gscdn.com%2F1tv%2F_definst_%2F1tv_5.stream/11/TV',
   'thumb':'http://img.kbs.co.kr/kplayer/WebV3/assets/images/channel_logo/large/channel_11.png'},  
    {'title':_L(30002),
   'url':'plugin://plugin.video.live-korean-tv/video/kbs/rtmp%3A%2F%2Flive.kbskme.gscdn.com%2Fnews24%2F_definst_%2Fnews24_800.stream/81/TV',
   'thumb':'http://img.kbs.co.kr/kplayer/WebV3/assets/images/channel_logo/large/channel_81.png'},
  {'title':_L(30016),
   'url':'plugin://plugin.video.live-korean-tv/video/eot/%2Furl2%3Fchannel%3D20%26player%3Dweb%26network%3Dpc/TV/0500',
   'thumb':'http://ytn.co.kr/img/_top/new_ytnlogo.gif'}
  ]

channels = [
  {'title':_L(30001),
   'url':'plugin://plugin.video.live-korean-tv/video/kbs/rtmp%3A%2F%2Flive.kbskme.gscdn.com%2F2tv%2F_definst_%2F2tv_5.stream/12/TV',
   'thumb':'http://img.kbs.co.kr/kplayer/WebV3/assets/images/channel_logo/large/channel_12.png'},
  {'title':_L(30003),
   'url':'plugin://plugin.video.live-korean-tv/video/kbs/rtmp%3A%2F%2Flive.kbskme.gscdn.com%2Fkbsn_drama%2F_definst_%2Fkbsn_drama_5.stream/N91/TV',
   'thumb':'http://img.kbs.co.kr/kplayer/WebV3/assets/images/channel_logo/large/channel_N91.png'},
  {'title':_L(30004),
   'url':'plugin://plugin.video.live-korean-tv/video/kbs/rtmp%3A%2F%2Flive.kbskme.gscdn.com%2Fkbsn_prime%2F_definst_%2Fkbsn_prime_5.stream/N93/TV',
   'thumb':'http://img.kbs.co.kr/kplayer/WebV3/assets/images/channel_logo/large/channel_N93.png'},
  {'title':_L(30005),
   'url':'plugin://plugin.video.live-korean-tv/video/kbs/rtmp%3A%2F%2Flive.kbskme.gscdn.com%2Fkbsn_joy%2F_definst_%2Fkbsn_joy_5.stream/N92/TV',
   'thumb':'http://img.kbs.co.kr/kplayer/WebV3/assets/images/channel_logo/large/channel_N92.png'},
  {'title':_L(30006),
   'url':'plugin://plugin.video.live-korean-tv/video/kbs/rtmp%3A%2F%2Flive.kbskme.gscdn.com%2Fkbs_worldtv%2F_definst_%2Fkbs_worldtv_4.stream/14/TV',
   'thumb':'http://img.kbs.co.kr/kplayer/WebV3/assets/images/channel_logo/large/channel_14.png'},
  {'title':_L(30007),
   'url':'plugin://plugin.video.live-korean-tv/video/mbc/%2Fplayer%2Fonair.aspx/TV/TV',
   'thumb':'http://image.tving.com/upload/cms/caic/CAIC0400/C00711.png'},
  {'title':_L(30008),
   'url':'plugin://plugin.video.live-korean-tv/video/mbc/%2Fplayer%2Fonairplus.aspx/TV/TV',
   'thumb':'http://guide.imbc.com/images/h2-onairplus.png'},
  {'title':_L(30009),
   'url':'plugin://plugin.video.live-korean-tv/video/sbs/%2Fonair%2Fonair_index.jsp%3FChannel%3DSBS/TV/TV',
   'thumb':'http://img.sbs.co.kr/sw11/sbs/onair/images/thumb_sbs.gif'},
  {'title':_L(30010),
   'url':'plugin://plugin.video.live-korean-tv/video/sbs/%2Fonair%2Fonair_index.jsp%3FChannel%3DCNBC/TV/TV',
   'thumb':'http://img.sbs.co.kr/sw11/sbs/onair/images/thumb_cnbc.gif'},
  {'title':_L(30011),
   'url':'plugin://plugin.video.live-korean-tv/video/sbs/%2Fonair%2Fonair_index.jsp%3FChannel%3DETV/TV/TV',
   'thumb':'http://img.sbs.co.kr/sw11/sbs/onair/images/thumb_fune.gif'},
  {'title':_L(30012),
   'url':'plugin://plugin.video.live-korean-tv/video/sbs/%2Fonair%2Fonair_index.jsp%3FChannel%3DGOLF/TV/TV',
   'thumb':'http://img.sbs.co.kr/sw11/sbs/onair/images/thumb_golf.gif'},
  {'title':_L(30013),
   'url':'plugin://plugin.video.live-korean-tv/video/sbs/%2Fonair%2Fonair_index.jsp%3FChannel%3DPLUS/TV/TV',
   'thumb':'http://img.sbs.co.kr/sw11/sbs/onair/images/thumb_plus.gif'},
  {'title':_L(30014),
   'url':'plugin://plugin.video.live-korean-tv/video/sbs/%2Fonair%2Fonair_index.jsp%3FChannel%3DSPORTS/TV/TV',
   'thumb':'http://img.sbs.co.kr/sw11/sbs/onair/images/thumb_sports.gif'},
  {'title':_L(30015),
   'url':'plugin://plugin.video.live-korean-tv/video/sbs/%2Fonair%2Fonair_index.jsp%3FChannel%3DMTV/TV/TV',
   'thumb':'http://img.sbs.co.kr/sw11/sbs/onair/images/thumb_mtv.gif'},
  {'title':_L(30017),
   'url':'plugin://plugin.video.live-korean-tv/video/eot/%2Furl2%3Fchannel%3D343%26player%3Dweb%26network%3Dpc/TV/0100',
   'thumb':'http://images.jtbc.joins.com/ui_jtbc/index/v3/t_jtbc_index.gif'}
  ]

vods = [
  {'title':_L(30021),
   'url':'plugin://plugin.video.tvbogo.com/onair/%3Fpg_mode%3Dxml%26code%3DB01',
   'playable':False},   
  {'title':_L(30022),
   'url':'plugin://plugin.video.tvbogo.com/onair/%3Fpg_mode%3Dxml%26code%3DB02',
   'playable':False},
  {'title':_L(30023),
   'url':'plugin://plugin.video.tvbogo.com/onair/%3Fpg_mode%3Dxml%26code%3DB03',
   'playable':False}
  ]

@plugin.route('/onair/')
def browseOnAir():
  result = []
  for channel in channels:      
    result.append({
      'label':channel['title'],
      'path':channel['url'], 
      'is_playable':channel.get('playable', True),
      'thumbnail':channel.get('thumb', '')})
  return result;

@plugin.route('/news/')
def browseNews():
  result = []
  for channel in news:      
    result.append({
      'label':channel['title'],
      'path':channel['url'], 
      'is_playable':channel.get('playable', True),
      'thumbnail':channel.get('thumb', '')})            
  return result;

@plugin.route('/vods/')
def browseVod():
  result = []
  for channel in vods:      
    result.append({
      'label':channel['title'],
      'path':channel['url'], 
      'is_playable':channel.get('playable', True),
      'thumbnail':channel.get('thumb', '')})            
  return result;

if __name__ == '__main__':
  plugin.run()
