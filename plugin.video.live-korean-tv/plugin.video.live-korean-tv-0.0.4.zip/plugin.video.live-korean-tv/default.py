from xbmcswift2 import Plugin, xbmc, xbmcgui, xbmcaddon
from lib import sbs, mbc, kbs
import re

plugin = "Live Korean TV"
__url__ = 'https://code.google.com/p/xbmc-korean-tv/'
__date__ = '05-22-2014'
__version__ = '0.0.4'
settings = xbmcaddon.Addon(id='plugin.video.live-korean-tv')
cookiepath = xbmc.translatePath('special://temp/')

plugin = Plugin()
kbs = kbs.KBS(cookiepath)
sbs = sbs.SBS(cookiepath)
mbc = mbc.MBC(cookiepath)

def strip_html(text):
  def fixup(m):
    text = m.group(0)
    if text[:1] == "<":
      return "" # ignore tags
    if text[:2] == "&#":
      try:
        if text[:3] == "&#x":
          return unichr(int(text[3:-1], 16))
        else:
          return unichr(int(text[2:-1]))
      except ValueError:
        pass
    elif text[:1] == "&":
      import htmlentitydefs
      entity = htmlentitydefs.entitydefs.get(text[1:-1])
      if entity:
        if entity[:2] == "&#":
          try:
            return unichr(int(entity[2:-1]))
          except ValueError:
            pass
        else:
          return unicode(entity, "iso-8859-1")
    return text # leave as is
  return re.sub("(?s)<[^>]*>|&#?\w+;", fixup, text)

def checkLoginInfo():
  if settings.getSetting('username') == '' or settings.getSetting('password') == '':
    settings.openSettings()
    return True
  return True

def addItems(items):
  result = []
  for item in items:
    title = item['title']
    playable = item.get('playable', False)
    ccode = item.get('channel_code', 'TV')
    ctype = item.get('channel_type', 'TV')
      
    result.append({
      'label':strip_html(item['title']),
      'path':plugin.url_for(item['mode'], url=item['url'], code=item['code'], channel_code=ccode, channel_type=ctype),
      'is_playable':playable,
      'thumbnail':item.get('thumb', '')})            
  return result;

@plugin.cached_route('/')
def index():
  result = []
  
  result.append({'label':u"[COLOR FFFF0000][B]KBS[/B][/COLOR]", 'path':plugin.url_for('index')})
  result += addItems(kbs.parseMenu())  
  
  result.append({'label':u"[COLOR FFFF0000][B]MBC[/B][/COLOR]", 'path':plugin.url_for('index')})
  result += addItems(mbc.parseMenu())

  items = ({'label':u"[COLOR FFFF0000][B]SBS[/B][/COLOR]", 'path':plugin.url_for('index')})
  result.append(items)
  result += addItems(sbs.parseMenu())
  
  return result

@plugin.route('/video/<code>/<url>/<channel_code>/<channel_type>')
def play(code, url, channel_code, channel_type):

  print code
  print url
  
  if code == 'sbs':
    info = sbs.parseVideo(url)
  elif code == 'mbc':
    info = mbc.parseVideo(url)
  elif code == 'kbs':
    print channel_code
    print channel_type
    info = kbs.parseVideo(channel_code, channel_type, url, plugin.get_setting('useProxy', bool))
    
  vurl = "{0:s} playpath={1:s} swfVfy=true live=true".format(info['base'], info['video'])
  
  print vurl
  
  plugin.set_resolved_url(vurl)   

if __name__ == '__main__':
  if checkLoginInfo():
    mbc.login(settings.getSetting('username'), settings.getSetting('password'), cookiepath)
    plugin.run()
