from xbmcswift2 import Plugin, xbmc, xbmcgui, xbmcaddon
from lib import sbs, mbc, kbs, eot
import re

plugin = "Live Korean TV"
__url__ = 'https://code.google.com/p/xbmc-korean-tv/'
__date__ = '05-28-2014'
__version__ = '0.0.7'
settings = xbmcaddon.Addon(id='plugin.video.live-korean-tv')
cookiepath = xbmc.translatePath('special://temp/')

plugin = Plugin()
kbs = kbs.KBS(cookiepath)
sbs = sbs.SBS(cookiepath)
mbc = mbc.MBC(cookiepath)
eot = eot.EOT(cookiepath)

channels = {'kbs':kbs, 'mbc':mbc, 'sbs':sbs, 'eot':eot}

def strip_html(text):
  def fixup(m):
    text = m.group(0)
    if text[:1] == "<":
      return "" # ignore tags
    if text[:2] == "&#":
      try:
        if text[:3] == "&#x":
          return unichr(int(text[3:-1], 16))
        else:
          return unichr(int(text[2:-1]))
      except ValueError:
        pass
    elif text[:1] == "&":
      import htmlentitydefs
      entity = htmlentitydefs.entitydefs.get(text[1:-1])
      if entity:
        if entity[:2] == "&#":
          try:
            return unichr(int(entity[2:-1]))
          except ValueError:
            pass
        else:
          return unicode(entity, "iso-8859-1")
    return text # leave as is
  return re.sub("(?s)<[^>]*>|&#?\w+;", fixup, text)

def checkLoginInfo():
  if settings.getSetting('username') == '' or settings.getSetting('password') == '':
    settings.openSettings()
    return True
  return True

def addItems(items):
  result = []
  for item in items:
    title = item['title']
    playable = item.get('playable', False)
    ccode = item.get('channel_code', 'TV')
    ctype = item.get('channel_type', 'TV')
      
    result.append({
      'label':strip_html(item['title']),
      'path':plugin.url_for(item['mode'], url=item['url'], code=item['code'], channel_code=ccode, channel_type=ctype),
      'is_playable':playable,
      'thumbnail':item.get('thumb', '')})            
  return result;


def getMenu(channel):
  storage = plugin.get_storage('live-korean-tv-menu')
  
  menu = storage.get(channel, None)

  if menu == None:
    print 'Get ' + channel + ' Channel from Web'
    menu = channels[channel].parseMenu()
    storage[channel] = menu

  return menu

@plugin.route('/')
def index():
  result = []
    
  result.append({'label':u"[COLOR FFFF0000][B]KBS[/B][/COLOR]", 'path':plugin.url_for('index')})
  result += addItems(getMenu('kbs'))  
  
  result.append({'label':u"[COLOR FFFF0000][B]MBC[/B][/COLOR]", 'path':plugin.url_for('index')})
  result += addItems(getMenu('mbc'))

  items = ({'label':u"[COLOR FFFF0000][B]SBS[/B][/COLOR]", 'path':plugin.url_for('index')})
  result.append(items)
  result += addItems(getMenu('sbs'))

  items = ({'label':u"[COLOR FFFF0000][B]EveryOn TV[/B][/COLOR]", 'path':plugin.url_for('index')})
  result.append(items)
  result += addItems(getMenu('eot'))
  
  return result

@plugin.route('/<code>/')
def browse(code):
  return addItems(channels[code].parseMenu())

@plugin.route('/video/<code>/<url>/<channel_code>/<channel_type>')
def play(code, url, channel_code, channel_type):

  print code
  print url
  
  if code == 'sbs':
    info = sbs.parseVideo(url)
  elif code == 'mbc':
    info = mbc.parseVideo(url)
  elif code == 'kbs':
    print channel_code
    print channel_type
    info = kbs.parseVideo(channel_code, channel_type, url, plugin.get_setting('useProxy', bool), plugin.get_storage('live-korean-tv', TTL=60))
  elif code == 'eot':
    info = eot.parseVideo(url, plugin.get_setting('useProxy', bool), plugin.get_storage('live-korean-tv', TTL=60))

  if info['video'] == '':
    vurl = "{0:s}".format(info['base'])
  else:
    vurl = "{0:s} playpath={1:s} swfVfy=true live=true".format(info['base'], info['video'])
  
  print vurl
  
  plugin.set_resolved_url(vurl)   

if __name__ == '__main__':
  if checkLoginInfo():
    mbc.login(settings.getSetting('username'), settings.getSetting('password'), cookiepath)
    plugin.run()
