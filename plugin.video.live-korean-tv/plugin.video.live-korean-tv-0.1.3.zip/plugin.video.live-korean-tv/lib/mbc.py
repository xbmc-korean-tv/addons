# -*- coding: utf-8 -*-
import urllib
import sys
import re
import navigator
import authenticator
import random
from pyDes import des

try:
    import CommonFunctions
    common = CommonFunctions
except:
    import CommonFunctions2 as common

# http://www.imbc.com

base_url = 'http://vodmall.imbc.com'
mypage_url = 'http://vodmall.imbc.com/player/onair.aspx'
channels = { 'isOnAir=Y' : 'http://vodmall.imbc.com/util/player/onairurlutil.ashx',
             'isMCast=Y' : 'http://vodmall.imbc.com/util/player/OnairUrlUtil_MCast.ashx'}
cookiefile = 'live-korean-tv_cookie.lwp'

# cookie = chk_idsafe = True. geo = KR


class MBC:

    def __init__(self, cookiepath):
        self.nav = navigator.Navigator(base_url)
        self.auth = authenticator.Login(self.nav.opener, self.nav.cj, cookiepath + cookiefile)
        
        try:
            self.language = sys.modules["__main__"].settings.getLocalizedString
        except:
            pass    

    def login(self, username, password, cookiepath):
        data = urllib.urlencode({'userid':username, 'userpw':password})

        page = self.nav.getPage(base_url=mypage_url)

        loginPage = common.parseDOM(page, 'form', {'name':'frmLogin'})

        if len(loginPage) != 0:
            loginPage = loginPage[0]
            login_url = common.parseDOM(page, 'form', {'name':'frmLogin'}, ret='action')[0].encode('utf-8')
            userid = common.parseDOM(loginPage, 'input', {'id':'lbl_id'}, ret='name')[0].encode('utf-8')
            pwdid =common.parseDOM(loginPage, 'input', {'id':'lbl_pwd'}, ret='name')[0].encode('utf-8')
            data = urllib.urlencode({'Uid':username, 'Password':password})
            self.auth.login(login_url, data, cookiepath + cookiefile)
    
    def parseMenu(self):
        page = self.nav.getPage(base_url=mypage_url)
        result = []
        channels = common.parseDOM(page, 'ul', {'class':'nav-primary'})
        items = common.parseDOM(channels, 'li')
        
        for item in items:
            try:
                item = item.encode('utf-8')
                title = common.parseDOM(item, 'a')[0]
                url = common.parseDOM(item, 'a', ret='href')[0].encode('utf-8')
                
                result.append({'title':title, 'code':'mbc', 'url':url, 'thumb':'', 'mode':'play', 'playable':'True'})
            except:
                continue
                        
        return result
    
    def parseVideo(self, url):
        try:
            result = []
            page = self.nav.getPage(url=url)
            url = re.compile('popPath = "(.*?)"', re.DOTALL).search(page).group(1)
            channel = self.nav.getPage(base_url=url)

            self.nav.opener.addheaders = [('Referer', url)]

            link = channels[url.split('?')[1]]

            channel = self.nav.opener.open(link).read()
        
            server = common.parseDOM(channel, 'rtmpserver')[0]
            server = re.compile('CDATA(.*?)]', re.DOTALL).search(server).group(1).replace('[', '').encode('utf-8')
            media = common.parseDOM(channel, 'mediaurl')[0]
            media = re.compile('CDATA(.*?)]', re.DOTALL).search(media).group(1).replace('[', '').encode('utf-8')
            authkey = media.split('?')

            base = server + '?' + authkey[1]
            vurl = media[1:]                
        except:
            base = 'mms://vod.mokpombc.co.kr/encoder-tv'
            vurl = ''
            
        return {'base':base, 'video':vurl}
    
# vim:sw=4:sts=4:et
