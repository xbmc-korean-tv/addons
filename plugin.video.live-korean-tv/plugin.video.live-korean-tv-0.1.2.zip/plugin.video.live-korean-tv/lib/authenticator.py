# -*- coding: utf-8 -*-
import os

class Login:

        def __init__(self, opener, cj, cookiefile='cookie.lwp'):
                self.cj = cj
                self.opener = opener

                if (os.path.isfile(cookiefile)):
                        self.cj.load(cookiefile, True)

        
        def login(self, login_url, data, cookiefile='cookie.lwp'):                
                if (os.path.isfile(cookiefile)):
                        self.cj.load(cookiefile, True)

                print 'Login to ' + login_url
                self.opener.open(login_url, data)
                self.cj.save(cookiefile, True)                

# vim:sw=4:sts=4:et
