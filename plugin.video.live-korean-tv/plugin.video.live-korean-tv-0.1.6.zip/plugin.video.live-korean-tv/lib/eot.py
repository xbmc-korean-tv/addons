# -*- coding: utf-8 -*-
import urllib, urllib2
import sys
import re
import navigator
import authenticator
import proxyFinder

try:    
    import CommonFunctions
    common = CommonFunctions
except:
    import CommonFunctions2 as common

# http://www.everyon.tv

base_url = 'http://www.everyon.tv/view/'
ch_pre_url = 'http://www.everyon.tv/data/ch_pre_pc_kr.xml'
ch_nor_url = 'http://www.everyon.tv/data/ch_nor_pc_kr.xml'
stream_url = 'http://cms.everyon.tv/isapi/v001/hcninfo.dll'

cookiefile = 'live-korean-tv_cookie.lwp'

class EOT:

    def __init__(self, cookiepath, channels):
        self.nav = navigator.Navigator(base_url)
        self.auth = authenticator.Login(self.nav.opener, self.nav.cj, cookiepath + cookiefile)
        

	# JTBC
        channels['/url2?channel=343&player=web&network=pc'] = 'edge1.everyon.tv/etv1/phd343?country=KR&quality=0&channel=343&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=896&server=peer'

	# YTN
        channels['/url2?channel=20&player=web&network=pc'] = 'edge1.everyon.tv/etv1sb/phd20?country=KR&quality=0&channel=20&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=1096&server=peer'

	# Channel A
        channels['/url2?channel=251&player=web&network=pc'] = 'edge1.everyon.tv/etv1/phd251?country=KR&quality=0&channel=251&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=896&server=peer'

	# MBN
        channels['/url2?channel=17&player=web&network=pc'] = 'edge1.everyon.tv/etv1/phd17?country=KR&quality=0&channel=17&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=896&server=peer'

	# TV Chosun
        channels['/url2?channel=341&player=web&network=pc'] = 'edge2.everyon.tv/etv2/phd341?country=KR&quality=0&channel=341&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=896&server=peer'

	# Donga
        channels['/url2?channel=43&player=web&network=pc'] = 'edge2.everyon.tv/etv2sb/phd43?country=KR&quality=0&channel=43&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=896&server=peer'

	# Yunhap News
        channels['/url2?channel=133&player=web&network=pc'] = 'edge2.everyon.tv/etv2/phd133?country=KR&quality=0&channel=133&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=896&server=peer'

	# SportsOne Golf
        channels['/url2?channel=423&player=web&network=pc'] = 'edge1.everyon.tv/etv1sb/phd423?country=KR&quality=0&channel=423&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=696&server=peer'

	# J Golf
        channels['/url2?channel=58&player=web&network=pc'] = 'edge1.everyon.tv/etv1sb/phd58?country=KR&quality=0&channel=58&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=896&server=peer'

	# Golf Meca
        channels['/url2?channel=929&player=web&network=pc'] = 'edge2.everyon.tv/etv2sb/phd929?country=KR&quality=0&channel=929&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=896&server=peer'

	# Golf Club H
        channels['/url2?channel=902&player=web&network=pc'] = 'edge2.everyon.tv/etv2sb/phd902?country=KR&quality=0&channel=902&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=696&server=peer'

	# PLAYY Premium Movie
        channels['/url2?channel=743&player=web&network=pc'] = 'edge2.everyon.tv/etv2sb/phd743?country=KR&quality=0&channel=743&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=1096&server=peer'

	# PLAYY Well Made Movie
        channels['/url2?channel=770&player=web&network=pc'] = 'edge2.everyon.tv/etv2sb/phd770?country=KR&quality=0&channel=770&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=1096&server=peer'

	# MOVIE & JOY
        channels['/url2?channel=509&player=web&network=pc'] = 'edge2.everyon.tv/etv2sb/phd509?country=KR&quality=0&channel=509&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=648&server=peer'

	# KIDS PLAY
        channels['/url2?channel=507&player=web&network=pc'] = 'edge2.everyon.tv/etv2sb/phd507?country=KR&quality=0&channel=507&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=696&server=peer'

	# Children's TV
        channels['/url2?channel=5&player=web&network=pc'] = 'edge1.everyon.tv/etv1sb/phd5?country=KR&quality=0&channel=5&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=896&server=peer'
 
	# ANI Friends
        channels['/url2?channel=933&player=web&network=pc'] = 'edge2.everyon.tv/etv2sb/phd933?country=KR&quality=0&channel=933&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=696&server=peer'

	# KIDS-TV
        channels['/url2?channel=1043&player=web&network=pc'] = 'edge2.everyon.tv/etv2/phd1043?country=KR&quality=0&channel=1043&player=web&network=pc&p2pupuser=on&domain=everyon&bitrate=696&server=peer'

        try:
            self.language = sys.modules["__main__"].settings.getLocalizedString
        except:
            pass        

    def getChannels(self, url):
        page = self.nav.getPage(url)
        result = []

        channels = common.parseDOM(page, 'item')
                
        for item in channels:
            try:
                id = common.parseDOM(item, 'id')[0].encode('utf-8')
                number = common.parseDOM(item, 'number')[0].encode('utf-8')
                name = common.parseDOM(item, 'name')[0]
                title = re.compile('CDATA\[(.*?)\]', re.DOTALL).search(name).group(1)
                category = common.parseDOM(item, 'category')[0].encode('utf-8')

                url = '/url2?channel=' + id + '&player=web&network=pc'
                result.append({'title':title, 'code':'eot', 'url':url, 'channel_type':category, 'thumb':'', 'mode':'play', 'playable':'True'})
            except:
                print item
                continue
                        
        return result

    def parseMenu(self):
        result = []
        result += self.getChannels(ch_nor_url)
        result += self.getChannels(ch_pre_url)

        return result
    
    def parseVideo(self, url, useProxy, storage, channels):
        result = []        

        vlink = channels.get(url, '')

        if vlink == '':
            if useProxy:
                vpage = proxyFinder.ProxyFinder().openPage(storage, stream_url + url)            
            else:
                opener = self.nav.opener        
                vpage = opener.open(stream_url + url).read()
            
            vprofile = common.parseDOM(vpage, 'path')[0]
            vlink = re.compile('CDATA\[(.*?)\]', re.DOTALL).search(vprofile).group(1).encode('utf-8')
            vlink = vlink[vlink.find('127.0.0.1/')+10:]
            
            print "Save " + url + ": " + vlink
            channels[url] = vlink

        idx = vlink.rfind('/') + 1
        base = 'rtmp://' + vlink[:idx]
        vurl = vlink[idx:]
        
        return {'base':base, 'video':vurl}
    
# vim:sw=4:sts=4:et
