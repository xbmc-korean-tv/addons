# -*- coding: utf-8 -*-
import urllib2, socket
import re

try:
    import CommonFunctions
    common = CommonFunctions
except:
    import CommonFunctions2 as common

socket.setdefaulttimeout(6000)

class ProxyFinder:

    def __init__(self):
        print 'Init: ProxyFinder'

    def getPage(self, pip, pageUrl, data):
        proxy_handler = urllib2.ProxyHandler({'http': pip})        
        opener = urllib2.build_opener(proxy_handler)
        opener.addheaders = [('User-agent', 'Mozilla/5.0')]
        urllib2.install_opener(opener)        
        req=urllib2.Request(pageUrl)  # change the url address here
        return urllib2.urlopen(req, data).read()        
        
    def openPage(self, storage, pageUrl, data='', proxyUrl='http://www.gatherproxy.com/proxylist/country/?c=republic-of-korea'):		
        try:
            pip = storage.get('proxy', '')

            print 'PIP: ' + pip
            
            if pip != '':
                print 'Open: ' + pageUrl + ' using Proxy: ' + pip
                return self.getPage(pip, pageUrl,data)
        except Exception, detail:
            print 'ERROR:', detail            
		
        opener = urllib2.build_opener()
        opener.addheaders = [('User-agent', 'Mozilla/5.0')]                
        page = opener.open(proxyUrl).read()


        plist1 = re.compile('"PROXY_IP":"(.*?)"'). findall(page)
        plist2 = re.compile('"PROXY_PORT":"(.*?)"'). findall(page)
        
        plist = zip(plist1, plist2)
        print plist
            
        for proxy in plist:
            ip = proxy[0]            
            if proxy[1] == '1F90':
                port = '8080'
            elif proxy[1] == '50':
                port = '80'
            else:
                continue

            pip = ip+':'+port

            print 'PIP: ' + pip
            try:
                page = self.getPage(pip, pageUrl, data)
                print 'Set Proxy: ' + pip
                storage['proxy'] = pip
                return page
            except Exception, detail:
                print 'Bad Proxy: ' + pip
                print 'ERROR:', detail


# vim:sw=4:sts=4:et
