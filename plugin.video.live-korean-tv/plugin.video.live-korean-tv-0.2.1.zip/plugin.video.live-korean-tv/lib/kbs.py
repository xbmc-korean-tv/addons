# -*- coding: utf-8 -*-
import urllib, urllib2
import sys
import re
import navigator
import authenticator
import random
import simplejson
import proxyFinder

from pyDes import des

try:    
    import CommonFunctions
    common = CommonFunctions
except:
    import CommonFunctions2 as common

# http://www.kbs.co.kr

base_url = 'http://myk.kbs.co.kr'
master_url = 'http://myk.kbs.co.kr/broadcast_live/channel_master_items_json'
stream_url = '/api/kp_cms/live_stream'

cookiefile = 'live-korean-tv_cookie.lwp'


class KBS:

    def __init__(self, cookiepath):
        self.nav = navigator.Navigator(base_url)
        self.auth = authenticator.Login(self.nav.opener, self.nav.cj, cookiepath + cookiefile)
        
        try:
            self.language = sys.modules["__main__"].settings.getLocalizedString
        except:
            pass    

    def login(self, username, password, cookiepath):
        data = urllib.urlencode({'userid':username, 'userpw':password})

        page = self.nav.getPage(base_url=mypage_url)

        loginPage = common.parseDOM(page, 'form', {'name':'frmLogin'})

        if len(loginPage) != 0:
            loginPage = loginPage[0]
            login_url = common.parseDOM(page, 'form', {'name':'frmLogin'}, ret='action')[0].encode('utf-8')
            userid = common.parseDOM(loginPage, 'input', {'id':'lbl_id'}, ret='name')[0].encode('utf-8')
            pwdid =common.parseDOM(loginPage, 'input', {'id':'lbl_pwd'}, ret='name')[0].encode('utf-8')
            data = urllib.urlencode({'Uid':username, 'Password':password})
            self.auth.login(login_url, data, cookiepath + cookiefile)
    
    def parseMenu(self):
        page = self.nav.getPage(master_url)
        result = []

        master = simplejson.loads(page)
        
        channels = master['live_episode_items']
                
        for item in master['live_episode_items']:
            try:
                if item['channel_type'] == 'TV':
                    code = item['channel_code']
                    title = code['label']
                    thumb = item['channel_image']['pc_l']
                    stream = item['normal_stream_info']                    
                    url = stream['service_url'].encode('utf-8')
                
                    result.append({'title':title, 'code':'kbs', 'url':url, 'channel_code':code['value'], 'thumb':thumb, 'stream':stream, 'mode':'play', 'playable':'True'})
            except:
                continue
                        
        return result

    
    def parseVideo(self, channel_code, channel_type, url, useProxy, storage):
        result = []

        data = urllib.urlencode({'channel_code':channel_code, 'channel_type':channel_type, 'service_url':url})

        if useProxy:
            vpage = proxyFinder.ProxyFinder().openPage(storage, base_url + stream_url, data)
        else:
            opener = self.nav.opener
            vpage = opener.open(base_url + stream_url, data).read()
        

        vlink = simplejson.loads(vpage)['real_service_url']
        
        base = vlink[:vlink.find('/_')]
        vurl = vlink[vlink.find('/_')-1:]                
        
        return {'base':base, 'video':vurl}
    
# vim:sw=4:sts=4:et
