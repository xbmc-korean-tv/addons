# -*- coding: utf-8 -*-
import urllib2, socket

try:
    import CommonFunctions
    common = CommonFunctions
except:
    import CommonFunctions2 as common

socket.setdefaulttimeout(60000)

class ProxyFinder:

    def __init__(self):
        print 'Init: ProxyFinder'

    def is_bad_proxy(self, pip):
        try:        
            proxy_handler = urllib2.ProxyHandler({'http': pip})        
            opener = urllib2.build_opener(proxy_handler)
            opener.addheaders = [('User-agent', 'Mozilla/5.0')]
            urllib2.install_opener(opener)        
            req=urllib2.Request('http://www.kbs.co.kr')  # change the url address here
            sock=urllib2.urlopen(req)
        except urllib2.HTTPError, e:        
            print 'Error code: ', e.code
            return e.code
        except Exception, detail:
            print "ERROR:", detail
            return 1
        return 0
        
    def getProxy(self, storage, proxyUrl='http://www.xroxy.com/proxylist.php?port=&type=All_http&ssl=&country=KR&latency=&reliability=#table'):		
        try:
            pip = storage.get('proxy', '')

            print 'PIP: ' + pip
            
            if pip != '':
                print 'Proxy: ' + pip + ' OK'	
                return pip            
	except:
            pass
		
	opener = urllib2.build_opener()
        opener.addheaders = [('User-agent', 'Mozilla/5.0')]                
        page = opener.open(proxyUrl).read()
        content = common.parseDOM(page, 'div', {'id':'content'})[0]
        plist = common.parseDOM(content, 'tr', {'class':'row0'})
        plist += common.parseDOM(content, 'tr', {'class':'row1'})

        for proxy in plist:
            pinfo = common.parseDOM(proxy, 'td')
            ip = common.parseDOM(pinfo[1], 'a')[0].encode('utf-8')
            ip = ip[:ip.find('\n')]
                        
            port = common.parseDOM(pinfo[2], 'a')[0].encode('utf-8')                        

            pip = ip+':'+port
            if self.is_bad_proxy(pip):
                print 'Bad Proxy: ' + pip
            else:
		print 'Set Proxy: ' + pip
		storage['proxy'] = pip
                return pip
								
# vim:sw=4:sts=4:et
