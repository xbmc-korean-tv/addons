# -*- coding: utf-8 -*-
import urllib
import sys
import re
import navigator
import random
from pyDes import des

try:
    import CommonFunctions
    common = CommonFunctions
except:
    import CommonFunctions2 as common

# http://www.sbs.co.kr

base_url = 'http://vod.sbs.co.kr'
channel_url = '/onair/common/html/tv_channel_list.html'
cookiefile = 'live-korean-tv_cookie.lwp'
keyDES = "7d1ff4ea";
key3DES = "7d1ff4ea8925c225";

cipher = des(keyDES)

class SBS:

    def __init__(self):
        self.nav = navigator.Navigator(base_url)
        
        try:
            self.language = sys.modules["__main__"].settings.getLocalizedString
        except:
            pass    
    
    def parseMenu(self):
        page = self.nav.getPage(url=channel_url)        
        result = []
        items = common.parseDOM(page, 'div', {'class':'thumb'})
        
        for item in items:
            try:
                title = common.parseDOM(item, 'a', ret='title')[0]
                url = common.parseDOM(item, 'a', ret='href')[0].encode('utf-8')
                img = common.parseDOM(item, 'a')[0]
                thumb = common.parseDOM(img, 'img', ret='src')[0]

                result.append({'title':title, 'url':url, 'thumb':thumb, 'mode':'play', 'playable':'True'})
            except:
                continue
                        
        return result

    def parseVideo(self, url):
        result = []
        page = self.nav.getPage(url=url)
        url = re.compile('"FlashVars" value="url=(.*?)"', re.DOTALL).search(page).group(1)
        channel = self.nav.getPage(base_url=url)
        sources = common.parseDOM(channel, 'SourceURL')[0]
        links = sources.encode('utf-8').split('/')
        vurl = links[4][:links[4].find(']')]
        
        authLink = 'http://api.sbs.co.kr/vod/_v1/Onair_Media_Auth_Security.jsp?playerType=flash&channelPath=' + links[3] + "&streamName=" + vurl + "&rnd=" + str(random.randint(0,255))
        authKey = cipher.decrypt(self.nav.getPage(authLink).decode('base64')).encode('base64').decode('base64').split('?')[1]

        base = 'rtmp://' + links[2] + '/' + links[3] + '?' + authKey
        
        return {'base':base, 'video':vurl}
    
# vim:sw=4:sts=4:et
