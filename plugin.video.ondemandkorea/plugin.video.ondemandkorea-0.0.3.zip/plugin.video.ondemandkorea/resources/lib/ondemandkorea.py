# -*- coding: utf-8 -*-
import urllib
import sys
import re
import navigator
import authenticator

try:
    import CommonFunctions
    common = CommonFunctions
except:
    import CommonFunctions2 as common

# http://www.ondemandkorea.com

base_url = 'http://www.ondemandkorea.com'
login_url = 'http://www.ondemandkorea.com/login?action=login'
mypage_url = 'http://www.ondemandkorea.com/profile'
cookiefile = 'ondemandkorea_cookie.lwp'

def high(options):
    index = [r for r, s in enumerate(options) if '720p' in s]

    if len(index) == 0:
        return options[0]
    
    return options[index[0]]

def med(options):
    index = [r for r, s in enumerate(options) if '480p' in s]

    if len(index) == 0:
        return low(options)
    
    return options[index[0]]

def low(options):
    index = [r for r, s in enumerate(options) if '240p' in s]

    if len(index) == 0:
        return options(len(options) - 1)
    
    return options[index[0]]

resolutions = { '0' : med, '1' : low, '2' : high}

class ODK:

    def __init__(self):
        self.nav = navigator.Navigator(base_url, {'name':'language', 'value':'kr', 'domain':'www.ondemandkorea.com'})
        self.auth = authenticator.Login(self.nav.opener, self.nav.cj)

        try:
            self.language = sys.modules["__main__"].settings.getLocalizedString
        except:
            pass
        
    def login(self, username, password, cookiepath):
        data = urllib.urlencode({'userid':username, 'userpw':password}) 
        #self.auth.login(login_url, mypage_url, data, cookiepath + cookiefile)

    def addItems(self, items):
        result = []
        for href, url in items:
            try:
                title = common.parseDOM(href, 'a', ret='title')[0]
                sindex = url.rfind('/')
                eindex = url.rfind("'")
                url = url[sindex:eindex]
                if url.find('.php') >= 0:
                    url = '/includes' + url
                result.append({'title':title, 'url':url, 'thumb':'', 'mode':'browse'})
            except:
                continue

        return result
    
    def addMenu(self, menu, classId):
        channels = common.parseDOM(menu, 'td', {'class':classId})
        codes = common.parseDOM(menu, 'td', {'class':classId}, ret='onclick')
        return self.addItems(zip (channels, codes))

    def addSubMenu(self, menu):
        result = []
        channels = common.parseDOM(menu, 'li')
        codes = common.parseDOM(menu, 'li', ret='onclick')    
        return self.addItems(zip (channels, codes))
    
    def parseMenu(self):
        page = self.nav.getPage()        
        result = []
        menu = common.parseDOM(page, 'div', {'class' : 'collapse navbar-collapse'})

        result += self.addMenu(menu, 'v-bar  left')
        result += self.addMenu(menu, 'v-bar ')
        result += self.addSubMenu(menu)
                        
        return result

    def parseNewMedia(self, url):
        result = []
        page = self.nav.getPage('/' + url)
        mlist = common.parseDOM(page, 'div', {'id':'new'})

        if len(mlist) == 0:
            items = common.parseDOM(page, 'div', {'class':'ep_box'})
        else:
            items = common.parseDOM(mlist, 'div', {'class':'ep_box'})

        if len(items) == 0:
            submenu = common.parseDOM(page, 'ul', {'class':'submenu'})
            items = common.parseDOM(submenu, 'li', {'id':"*'"})
            for item in items:
                try:
                    url = '/' + common.parseDOM(item, 'a', ret='href')[0]
                    title = common.parseDOM(item, 'a')[0]
                    thumb = ''
                    result.append({'title':title, 'url':url, 'thumb':thumb, 'mode':'play', 'playable':'True'})
                except:
                    continue
                
        for item in items:
            try:
                title = common.parseDOM(item, 'a', ret='title')[0]
                url = '/' + common.parseDOM(item, 'a', ret='href')[0]
                thumb = common.parseDOM(item, 'img', ret='src')[0] 
                result.append({'title':title, 'url':url, 'thumb':thumb, 'mode':'play', 'playable':'True'})
            except:
                continue
            
        return result

    def parseVideo(self, url, quality):
        result = []
        print url
        page = self.nav.getPage(url)
        vcode = re.compile('token=(.*?)"', re.DOTALL).search(page).group(1)
        plist = '/includes/playlist.php?token=' + vcode
        vlist = self.nav.getPage(plist)
        base = common.parseDOM(vlist, 'meta', ret='base')[0]
        videos = common.parseDOM(vlist, 'video', ret='src')
        vurl = resolutions[quality](videos)
        
        return {'base':base, 'video':vurl}
    
# vim:sw=4:sts=4:et
