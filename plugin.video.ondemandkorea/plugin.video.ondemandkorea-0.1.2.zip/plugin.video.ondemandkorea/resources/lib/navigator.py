# -*- coding: utf-8 -*-
import urllib2
import cookielib

class Navigator:

        def __init__(self, base_url, ck):
                print 'Init: Navigator (' + base_url + ')'
                self.base_url = base_url
                self.cj = cookielib.LWPCookieJar()
                self.cj.set_cookie(cookielib.Cookie(version=0, name=ck['name'], value=ck['value'], port=None, port_specified=False, domain=ck['domain'], domain_specified=False, domain_initial_dot=False, path='/', path_specified=True, secure=False, expires=None, discard=True, comment=None, comment_url=None, rest={'HttpOnly': None}, rfc2109=False))
                self.opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(self.cj))
                self.opener.addheaders = [('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36'), ('Cookie', 'cf_clearance=31a17103a6d925b8e313809458a1351fad85de98-1465959229-10800;language=kr')]
                
        def getPage(self, url=''):
                page = self.opener.open(self.base_url + url).read()
                return page        
        
# vim:sw=4:sts=4:et
