# -*- coding: utf-8 -*-
import os

class Login:

        def __init__(self, opener, cj):
                self.cj = cj
                self.opener = opener
  
        def login(self, login_url, mypage_url, data, cookiefile='cookie.lwp'):                
                if (os.path.isfile(cookiefile)):
                        self.cj.load(cookiefile, True)

                page = self.opener.open(mypage_url).read()
                if page.find('window.self.location.replace') != -1:
                        print 'Login to ' + login_url
                        self.opener.open(login_url, data)
                        self.cj.save(cookiefile, True)                

# vim:sw=4:sts=4:et
